from django.shortcuts import render
from .models import *

# Create your views here.

def view(request):
    context = {
        'students': Student.objects.all(), 
    }
    return render(request, 'pages/view.html', context)
def home(request):
    return render(request, 'pages/homepage.html')

def index(request):
    return render(request, 'pages/index.html')
